package com.uade.tpo.demo.entity.dto;

import lombok.Data;

@Data
public class CategoryRequest {
    private int id;
    private String description;
}
